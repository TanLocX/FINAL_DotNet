======================================================================
  PNJ JEWELRY STORE MANAGEMENT SYSTEM - ENTERPRISE EDITION v2.0
======================================================================

1. QUICK START:
   - Run "Setup_Installer.bat" to verify prerequisites and setup desktop shortcut.
   - Or run "Launch_App.bat" (or FINAL_DotNet.exe) directly.

2. SYSTEM REQUIREMENTS:
   - Windows 10 / Windows 11 (x86 or x64)
   - Microsoft .NET Framework 4.7.2 or higher
   - Microsoft SQL Server (LocalDB, SQL Express, or Standard Edition)

3. DATABASE ATTACHMENT / RESTORE:
   - Database name: QL_CuaHangDaQuy_PNJ
   - Backup file: Located in "Database\QL_CuaHangDaQuy_PNJ.bak"
   - You can restore this backup via SQL Server Management Studio (SSMS)
     or via the built-in "Sao luu / Phuc hoi" module inside the app.

4. DEFAULT LOGIN ACCOUNTS:
   - Administrator: admin / admin123
   - Staff Cashier:  nhanvien / nv123
======================================================================
